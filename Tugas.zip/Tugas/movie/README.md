# Codepolitan-Movie
Example how to make pagination 

![Output Program](https://i.imgur.com/XYnvNFp.png)
